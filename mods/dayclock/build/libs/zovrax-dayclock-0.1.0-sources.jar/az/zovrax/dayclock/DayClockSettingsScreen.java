package az.zovrax.dayclock;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/** Settings are local to the client and each toggle persists immediately. */
public final class DayClockSettingsScreen extends class_437 {
    private final class_437 parent;
    private final DayClockConfig config = DayClockClient.config();
    private int page = 0;

    public DayClockSettingsScreen(class_437 parent) {
        super(class_2561.method_43470("DayClock HUD settings"));
        this.parent = parent;
    }

    @Override protected void method_25426() {
        int w = Math.min(290, Math.max(150, field_22789-28));
        int x = (field_22789-w)/2;
        int gap = 23;
        int top = Math.max(22, (field_22790-9*gap-15)/2);
        if (page == 0) {
            toggle(x,top,w,"HUD",()->config.enabled,v->config.enabled=v);
            toggle(x,top+gap,w,"World day",()->config.showDay,v->config.showDay=v);
            toggle(x,top+2*gap,w,"Game time + sleep icon",()->config.showTime,v->config.showTime=v);
            toggle(x,top+3*gap,w,"XYZ coordinates",()->config.showCoordinates,v->config.showCoordinates=v);
            toggle(x,top+4*gap,w,"Biome",()->config.showBiome,v->config.showBiome=v);
            toggle(x,top+5*gap,w,"Dimension",()->config.showDimension,v->config.showDimension=v);
            toggle(x,top+6*gap,w,"Facing direction",()->config.showFacing,v->config.showFacing=v);
            method_37063(class_4185.method_46430(class_2561.method_43470("More options >"), b -> goTo(1)).method_46434(x,top+7*gap,w,20).method_46431());
            method_37063(class_4185.method_46430(class_2561.method_43470("Done"), b -> method_25419()).method_46434(x,top+8*gap,w,20).method_46431());
        } else {
            toggle(x,top,w,"Weather",()->config.showWeather,v->config.showWeather=v);
            toggle(x,top+gap,w,"Light level",()->config.showLight,v->config.showLight=v);
            method_37063(new DayClockSlider(x,top+2*gap,w,"HUD size",50,200,5,()->config.scale,v->config.scale=v));
            method_37063(new DayClockSlider(x,top+3*gap,w,"HUD opacity",0,100,5,()->config.opacity,v->config.opacity=v));
            method_37063(new DayClockSlider(x,top+4*gap,w,"Background",0,100,5,()->config.backgroundOpacity,v->config.backgroundOpacity=v));
            method_37063(class_4185.method_46430(class_2561.method_43470("Move HUD on screen"), b -> {
                config.save();
                if (field_22787 != null) field_22787.method_1507(new DayClockPositionScreen(this));
            }).method_46434(x,top+5*gap,w,20).method_46431());
            method_37063(class_4185.method_46430(class_2561.method_43470("< Back to visibility"), b -> goTo(0)).method_46434(x,top+7*gap,w,20).method_46431());
            method_37063(class_4185.method_46430(class_2561.method_43470("Done"), b -> method_25419()).method_46434(x,top+8*gap,w,20).method_46431());
        }
    }

    private void toggle(int x,int y,int w,String label,BooleanSupplier getter,Consumer<Boolean> setter) {
        method_37063(class_4185.method_46430(class_2561.method_43470(label+": "+(getter.getAsBoolean()?"ON":"OFF")), b -> {
            setter.accept(!getter.getAsBoolean()); config.save();
            b.method_25355(class_2561.method_43470(label+": "+(getter.getAsBoolean()?"ON":"OFF")));
        }).method_46434(x,y,w,20).method_46431());
    }

    private void goTo(int n) { page=n; method_41843(); }

    @Override public void method_25394(class_332 ctx,int mouseX,int mouseY,float delta) {
        method_25420(ctx,mouseX,mouseY,delta);
        ctx.method_27534(field_22793,field_22785,field_22789/2,8,0xFFFFFFFF);
        super.method_25394(ctx,mouseX,mouseY,delta);
    }

    @Override public void method_25419() {
        config.save();
        if (field_22787 != null) field_22787.method_1507(parent);
    }
}
