package az.zovrax.dayclock;

import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

/** The preview follows the cursor only while the preview itself is dragged. */
public final class DayClockPositionScreen extends class_437 {
    private final class_437 parent;
    private final DayClockConfig config = DayClockClient.config();
    private boolean dragging;

    public DayClockPositionScreen(class_437 parent) {
        super(class_2561.method_43470("Move DayClock HUD"));
        this.parent = parent;
    }

    @Override protected void method_25426() {
        method_37063(class_4185.method_46430(class_2561.method_43470("Done"), b -> method_25419())
            .method_46434(field_22789/2-50,field_22790-28,100,20).method_46431());
    }

    private int px() { return DayClockHud.x(config,class_310.method_1551(),field_22789); }
    private int py() { return DayClockHud.y(config,class_310.method_1551(),field_22790); }
    private int pw() { return DayClockHud.width(config,class_310.method_1551()); }
    private int ph() { return DayClockHud.height(config,class_310.method_1551()); }

    @Override public boolean method_25402(class_11909 click,boolean doubled) {
        // Buttons must get first chance, otherwise the Done button can be
        // accidentally swallowed by the drag handler when HUD is moved there.
        if (super.method_25402(click,doubled)) return true;
        if (click.comp_4800().comp_4801() == GLFW.GLFW_MOUSE_BUTTON_LEFT
            && click.comp_4798() >= px() && click.comp_4798() < px()+pw()
            && click.comp_4799() >= py() && click.comp_4799() < py()+ph()) {
            dragging = true;
            return true;
        }
        return false;
    }

    @Override public boolean method_25403(class_11909 click,double dx,double dy) {
        if (!dragging) return super.method_25403(click,dx,dy);
        config.x = Math.clamp(config.x+dx/Math.max(1d,field_22789-pw()),0d,1d);
        config.y = Math.clamp(config.y+dy/Math.max(1d,field_22790-ph()),0d,1d);
        return true;
    }

    @Override public boolean method_25406(class_11909 click) {
        if (dragging) {
            dragging=false;
            config.save();
            return true;
        }
        return super.method_25406(click);
    }

    @Override public void method_25394(class_332 ctx,int mouseX,int mouseY,float delta) {
        method_25420(ctx,mouseX,mouseY,delta);
        DayClockHud.preview(ctx,config,px(),py());
        int x=px(),y=py(),w=pw(),h=ph();
        // Outline remains visible even when background/overall opacity are 0.
        ctx.method_25294(x,y,x+w,y+1,0xDDFFFFFF);
        ctx.method_25294(x,y+h-1,x+w,y+h,0xDDFFFFFF);
        ctx.method_25294(x,y,x+1,y+h,0xDDFFFFFF);
        ctx.method_25294(x+w-1,y,x+w,y+h,0xDDFFFFFF);
        super.method_25394(ctx,mouseX,mouseY,delta);
        ctx.method_27534(field_22793,class_2561.method_43470("Drag widget to move"),field_22789/2,12,0xFFFFFFFF);
    }

    @Override public void method_25419() {
        dragging=false;
        config.save();
        if (field_22787 != null) field_22787.method_1507(parent);
    }
}
