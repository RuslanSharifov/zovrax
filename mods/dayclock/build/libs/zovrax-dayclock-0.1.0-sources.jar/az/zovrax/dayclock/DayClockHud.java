package az.zovrax.dayclock;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_9779;

/** Compact text HUD; draws the sun or moon with pixels, no font glyph dependencies. */
public final class DayClockHud {
    private static final int PADDING = 7;
    private static final int ROW_HEIGHT = 12;
    private DayClockHud() { }

    public static boolean sleepWindow(class_310 mc) {
        if (mc.field_1687 == null || mc.field_1724 == null) return false;
        // Respect whether beds work in this dimension. This is a time eligibility
        // indicator; obstacles, nearby monsters and bed occupancy are not checked.
        return mc.field_1687.method_8597().comp_648() && (!mc.field_1687.method_8530() || mc.field_1687.method_8546());
    }

    private static String prettify(String value) {
        String name = value.replace('_', ' ');
        if (name.isEmpty()) return "Unknown";
        return name.substring(0, 1).toUpperCase(Locale.ROOT) + name.substring(1);
    }

    private static List<String> lines(class_310 mc, DayClockConfig cfg, boolean preview) {
        ArrayList<String> values = new ArrayList<>();
        if (mc.field_1687 == null || mc.field_1724 == null) {
            if (preview) {
                if (cfg.showDay) values.add("Day 1");
                if (cfg.showTime) values.add("Clock 06:00");
                if (cfg.showCoordinates) values.add("XYZ 0, 64, 0");
                if (cfg.showBiome) values.add("Biome Plains");
                if (cfg.showDimension) values.add("Dimension Overworld");
                if (cfg.showFacing) values.add("Facing North");
                if (cfg.showWeather) values.add("Weather Clear");
                if (cfg.showLight) values.add("Light 15");
            }
            return values;
        }
        class_2338 pos = mc.field_1724.method_24515();
        if (cfg.showDay) values.add("Day " + ClockMath.displayedDay(mc.field_1687.method_8532()));
        if (cfg.showTime) values.add("Clock " + ClockMath.clock(mc.field_1687.method_8532()));
        if (cfg.showCoordinates) values.add("XYZ " + pos.method_10263() + ", " + pos.method_10264() + ", " + pos.method_10260());
        if (cfg.showBiome) {
            String biome = mc.field_1687.method_23753(pos).method_40230().map(key -> key.method_29177().method_12832()).orElse("unknown");
            values.add("Biome " + prettify(biome));
        }
        if (cfg.showDimension) values.add("Dimension " + prettify(mc.field_1687.method_27983().method_29177().method_12832()));
        if (cfg.showFacing) values.add("Facing " + prettify(mc.field_1724.method_5735().method_15434()));
        if (cfg.showWeather) values.add("Weather " + (mc.field_1687.method_8546() ? "Thunder" : mc.field_1687.method_8419() ? "Rain" : "Clear"));
        if (cfg.showLight) values.add("Light " + mc.field_1687.method_22339(pos));
        return values;
    }

    private static int contentWidth(class_310 mc, List<String> lines, DayClockConfig cfg) {
        int text = 52;
        for (String line : lines) text = Math.max(text, mc.field_1772.method_1727(line));
        return PADDING * 2 + text + (cfg.showTime ? 17 : 0);
    }

    private static int contentHeight(List<String> lines) {
        return PADDING * 2 + lines.size() * ROW_HEIGHT;
    }

    public static int width(DayClockConfig cfg, class_310 mc) {
        return Math.round(contentWidth(mc, lines(mc, cfg, true), cfg) * cfg.scale / 100f);
    }

    public static int height(DayClockConfig cfg, class_310 mc) {
        return Math.round(contentHeight(lines(mc, cfg, true)) * cfg.scale / 100f);
    }

    public static int x(DayClockConfig cfg, class_310 mc, int screenWidth) {
        return (int) Math.round(cfg.x * Math.max(0, screenWidth - width(cfg, mc)));
    }

    public static int y(DayClockConfig cfg, class_310 mc, int screenHeight) {
        return (int) Math.round(cfg.y * Math.max(0, screenHeight - height(cfg, mc)));
    }

    public static void render(class_332 ctx, class_9779 ignored) {
        class_310 mc = class_310.method_1551();
        DayClockConfig cfg = DayClockClient.config();
        if (!cfg.enabled || mc.field_1724 == null || mc.field_1687 == null || mc.field_1755 != null) return;
        if (mc.field_1690.field_1842) return;
        draw(ctx, mc, cfg, x(cfg, mc, ctx.method_51421()),
            y(cfg, mc, ctx.method_51443()), false);
    }

    public static void preview(class_332 ctx, DayClockConfig cfg, int x, int y) {
        draw(ctx, class_310.method_1551(), cfg, x, y, true);
    }

    private static void draw(class_332 ctx, class_310 mc, DayClockConfig cfg, int px, int py, boolean preview) {
        List<String> values = lines(mc, cfg, preview);
        if (values.isEmpty() || cfg.opacity == 0) return;
        int w = contentWidth(mc, values, cfg);
        int h = contentHeight(values);
        int alpha = Math.clamp(cfg.opacity * 255 / 100, 0, 255);
        int bg = Math.clamp(cfg.backgroundOpacity * alpha / 100, 0, 255);
        ctx.method_51448().pushMatrix();
        try {
            ctx.method_51448().translate(px, py);
            ctx.method_51448().scale(cfg.scale / 100f, cfg.scale / 100f);
            if (bg > 0) ctx.method_25294(0, 0, w, h, (bg << 24) | 0x0C1722);
            int lineIndex = 0;
            for (String value : values) {
                int ty = PADDING + lineIndex * ROW_HEIGHT + 1;
                int textColor = (alpha << 24) | 0xF7F9FE;
                ctx.method_25303(mc.field_1772, value, PADDING, ty, textColor);
                if (cfg.showTime && value.startsWith("Clock ")) {
                    drawSkyIcon(ctx, w - PADDING - 11, ty - 1, sleepWindow(mc), alpha);
                }
                lineIndex++;
            }
        } finally {
            ctx.method_51448().popMatrix();
        }
    }

    private static void drawSkyIcon(class_332 ctx, int x, int y, boolean sleepAllowed, int alpha) {
        if (sleepAllowed) {
            // Crescent rendered directly from transparent pixels; no opaque
            // cutout that would obscure the game on a transparent overlay.
            final int moon = (alpha << 24) | 0xB6CFFF;
            int[][] rows = {
                {4, 6}, {2, 5}, {1, 4}, {0, 3}, {0, 3},
                {0, 3}, {1, 4}, {2, 5}, {4, 6}
            };
            for (int dy = 0; dy < rows.length; dy++) {
                ctx.method_25294(x + rows[dy][0], y + dy,
                    x + rows[dy][1] + 1, y + dy + 1, moon);
            }
        } else {
            final int sun = (alpha << 24) | 0xFFD66B;
            ctx.method_25294(x+4,y,x+6,y+2,sun);
            ctx.method_25294(x+4,y+8,x+6,y+10,sun);
            ctx.method_25294(x,y+4,x+2,y+6,sun);
            ctx.method_25294(x+8,y+4,x+10,y+6,sun);
            ctx.method_25294(x+3,y+3,x+7,y+7,sun);
            ctx.method_25294(x+2,y+2,x+3,y+3,sun);
            ctx.method_25294(x+7,y+7,x+8,y+8,sun);
            ctx.method_25294(x+7,y+2,x+8,y+3,sun);
            ctx.method_25294(x+2,y+7,x+3,y+8,sun);
        }
    }
}
