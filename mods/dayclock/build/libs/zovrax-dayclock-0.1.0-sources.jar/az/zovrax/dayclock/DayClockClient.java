package az.zovrax.dayclock;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

/** Registers a minimal client-only HUD and an independent settings hotkey. */
public final class DayClockClient implements ClientModInitializer {
    public static final String ID = "zovrax_dayclock";
    private static final DayClockConfig CONFIG = DayClockConfig.load();
    private class_304 settingsKey;

    public static DayClockConfig config() { return CONFIG; }

    @Override
    public void onInitializeClient() {
        class_304.class_11900 category = class_304.class_11900.method_74698(class_2960.method_60655(ID, "main"));
        settingsKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.zovrax_dayclock.settings", class_3675.class_307.field_1668, GLFW.GLFW_KEY_K, category));
        ClientTickEvents.END_CLIENT_TICK.register(this::endTick);
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
            class_2960.method_60655(ID, "overlay"), DayClockHud::render);
    }

    private void endTick(class_310 client) {
        while (settingsKey.method_1436()) {
            if (client.field_1724 != null && client.field_1755 == null) {
                client.method_1507(new DayClockSettingsScreen(null));
            }
        }
    }
}
