package az.zovrax.dayclock;

import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import net.minecraft.class_2561;
import net.minecraft.class_357;

/** Native slider with immediate save, no special config GUI dependency. */
public final class DayClockSlider extends class_357 {
    private final String name;
    private final int min, max, step;
    private final IntConsumer setter;

    public DayClockSlider(int x, int y, int w, String name, int min, int max, int step,
                          IntSupplier getter, IntConsumer setter) {
        super(x, y, w, 20, class_2561.method_43473(), (getter.getAsInt()-min)/(double)(max-min));
        this.name=name; this.min=min; this.max=max; this.step=step; this.setter=setter;
        method_25346();
    }

    private int current() {
        int raw = min + (int)Math.round(field_22753 * (max-min));
        return Math.clamp(min + Math.round((raw-min)/(float)step)*step, min, max);
    }

    @Override protected void method_25346() {
        method_25355(class_2561.method_43470(name+": "+current()+"%"));
    }

    @Override protected void method_25344() {
        setter.accept(current());
        DayClockClient.config().save();
        method_25346();
    }
}
