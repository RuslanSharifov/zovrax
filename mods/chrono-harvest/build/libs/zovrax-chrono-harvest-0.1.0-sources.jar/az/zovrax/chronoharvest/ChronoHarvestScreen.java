package az.zovrax.chronoharvest;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
public final class ChronoHarvestScreen extends class_437 {
 private final class_437 parent;
 public ChronoHarvestScreen(class_437 p){super(class_2561.method_43470("ChronoHarvest Settings"));parent=p;}
 @Override protected void method_25426(){
  int w=Math.min(300,field_22789-24),x=(field_22789-w)/2,y=Math.max(36,(field_22790-150)/2);
  method_37063(class_4185.method_46430(label("Mod enabled",ChronoHarvest.CONFIG.enabled),b->{ChronoHarvest.CONFIG.enabled=!ChronoHarvest.CONFIG.enabled;ChronoHarvest.CONFIG.save();b.method_25355(label("Mod enabled",ChronoHarvest.CONFIG.enabled));}).method_46434(x,y,w,20).method_46431());
  method_37063(class_4185.method_46430(class_2561.method_43470("Growth time / stage: "+ChronoHarvest.CONFIG.secondsPerStage+" sec"),b->{int[] v={60,120,180,240,300,420,600,900,1200,1800,2400,3600};int n=60;for(int a:v)if(a>ChronoHarvest.CONFIG.secondsPerStage){n=a;break;}ChronoHarvest.CONFIG.secondsPerStage=n;ChronoHarvest.CONFIG.save();b.method_25355(class_2561.method_43470("Growth time / stage: "+n+" sec"));}).method_46434(x,y+25,w,20).method_46431());
  method_37063(class_4185.method_46430(label("Require Shift for early harvest",ChronoHarvest.CONFIG.requireShiftForImmatureHarvest),b->{ChronoHarvest.CONFIG.requireShiftForImmatureHarvest=!ChronoHarvest.CONFIG.requireShiftForImmatureHarvest;ChronoHarvest.CONFIG.save();b.method_25355(label("Require Shift for early harvest",ChronoHarvest.CONFIG.requireShiftForImmatureHarvest));}).method_46434(x,y+50,w,20).method_46431());
  method_37063(class_4185.method_46430(label("Replant after harvest",ChronoHarvest.CONFIG.regrowAfterHarvest),b->{ChronoHarvest.CONFIG.regrowAfterHarvest=!ChronoHarvest.CONFIG.regrowAfterHarvest;ChronoHarvest.CONFIG.save();b.method_25355(label("Replant after harvest",ChronoHarvest.CONFIG.regrowAfterHarvest));}).method_46434(x,y+75,w,20).method_46431());
  method_37063(class_4185.method_46430(class_2561.method_43470("Done"),b->method_25419()).method_46434(x,y+110,w,20).method_46431());
 }
 private static class_2561 label(String s,boolean v){return class_2561.method_43470(s+": "+(v?"ON":"OFF"));}
 @Override public void method_25394(class_332 c,int mx,int my,float d){method_25420(c,mx,my,d);c.method_27534(field_22793,field_22785,field_22789/2,14,0xFFFFFFFF);c.method_27534(field_22793,class_2561.method_43470("Elapsed time is applied when crop chunks load."),field_22789/2,26,0xFFB8D7B4);super.method_25394(c,mx,my,d);}
 @Override public void method_25419(){ChronoHarvest.CONFIG.save();if(field_22787!=null)field_22787.method_1507(parent);}
}
