package az.zovrax.chronoharvest.mixin;
import az.zovrax.chronoharvest.GrowthLedger;
import net.minecraft.class_1269;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(class_1747.class)
public abstract class BlockItemMixin {
 @Inject(method="place",at=@At("RETURN"))
 private void chronoHarvest$recordPlanting(class_1750 context,CallbackInfoReturnable<class_1269> cir){
  if(!cir.getReturnValue().method_23665())return;class_1937 w=context.method_8045();if(!(w instanceof class_3218 sw))return;
  class_2680 s=w.method_8320(context.method_8037());if(GrowthLedger.supported(s))GrowthLedger.markPlanted(sw,context.method_8037());
 }
}
