package az.zovrax.chronoharvest;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;
public final class ChronoHarvestClient implements ClientModInitializer {
 @Override public void onInitializeClient(){
  class_304 key=KeyBindingHelper.registerKeyBinding(new class_304("key.zovrax_chronoharvest.settings",class_3675.class_307.field_1668,GLFW.GLFW_KEY_K,class_304.class_11900.method_74698(class_2960.method_60655(ChronoHarvest.ID,"main"))));
  ClientTickEvents.END_CLIENT_TICK.register(client->{while(key.method_1436())if(client.field_1724!=null&&client.field_1755==null)client.method_1507(new ChronoHarvestScreen(null));});
 }
}
