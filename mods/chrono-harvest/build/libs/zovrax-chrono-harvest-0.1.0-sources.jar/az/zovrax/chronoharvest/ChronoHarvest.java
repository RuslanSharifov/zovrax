package az.zovrax.chronoharvest;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerChunkEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
public final class ChronoHarvest implements ModInitializer {
 public static final String ID="zovrax_chronoharvest";
 public static final ChronoHarvestConfig CONFIG=ChronoHarvestConfig.load();
 @Override public void onInitialize(){
  ServerLifecycleEvents.SERVER_STARTED.register(GrowthLedger::load);
  ServerLifecycleEvents.SERVER_STOPPING.register(GrowthLedger::save);
  ServerChunkEvents.CHUNK_LOAD.register(GrowthLedger::onChunkLoad);
  ServerTickEvents.END_SERVER_TICK.register(server->GrowthLedger.periodicSave());
  PlayerBlockBreakEvents.BEFORE.register((world,player,pos,state,blockEntity)->{
   if(world.method_8608()||!(world instanceof class_3218 sw)||!(player instanceof class_3222 sp)||!GrowthLedger.supported(state))return true;
   var age=GrowthLedger.ageProperty(state); if(age==null)return true;
   int current=state.method_11654(age), max=age.method_11898().stream().mapToInt(Integer::intValue).max().orElse(current);
   boolean mature=current>=max;
   if(!mature&&CONFIG.requireShiftForImmatureHarvest&&!sp.method_5715()){
    sp.method_7353(class_2561.method_43470("ChronoHarvest: not ripe yet. Hold Shift to harvest early."),true);return false;
   }
   if(!mature&&!sp.method_5715())return false;
   if(CONFIG.regrowAfterHarvest){
    net.minecraft.class_2248.method_9511(state,sw,pos,blockEntity,sp,sp.method_6047());
    sw.method_8652(pos,state.method_11657(age,0),3); GrowthLedger.markPlanted(sw,pos); return false;
   }
   GrowthLedger.forget(sw,pos); return true;
  });
 }
}
