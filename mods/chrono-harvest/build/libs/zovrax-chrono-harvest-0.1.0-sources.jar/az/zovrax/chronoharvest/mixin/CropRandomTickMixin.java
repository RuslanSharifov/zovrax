package az.zovrax.chronoharvest.mixin;
import az.zovrax.chronoharvest.GrowthLedger;
import net.minecraft.class_2282;
import net.minecraft.class_2302;
import net.minecraft.class_2338;
import net.minecraft.class_2421;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3830;
import net.minecraft.class_5819;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin({class_2302.class,class_2421.class,class_3830.class,class_2282.class})
public abstract class CropRandomTickMixin {
 @Inject(method="randomTick",at=@At("HEAD"),cancellable=true)
 private void chronoHarvest$elapsedGrowth(class_2680 state,class_3218 world,class_2338 pos,class_5819 random,CallbackInfo ci){
  if(GrowthLedger.applyElapsedGrowth(world,pos))ci.cancel();
 }
}
