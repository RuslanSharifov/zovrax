package az.zovrax.chronoharvest;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.minecraft.class_2282;
import net.minecraft.class_2302;
import net.minecraft.class_2338;
import net.minecraft.class_2421;
import net.minecraft.class_2680;
import net.minecraft.class_2758;
import net.minecraft.class_2769;
import net.minecraft.class_2818;
import net.minecraft.class_3218;
import net.minecraft.class_3830;
import net.minecraft.class_5218;
import net.minecraft.server.MinecraftServer;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
public final class GrowthLedger {
 private static final Gson GSON=new GsonBuilder().setPrettyPrinting().create();
 private static final Type TYPE=new TypeToken<Map<String,Long>>(){}.getType();
 private static final Map<String,Long> PLANTED=new HashMap<>();
 private static Path file; private static long lastSave; private static MinecraftServer server;
 private GrowthLedger(){}
 public static boolean supported(class_2680 s){var b=s.method_26204();return b instanceof class_2302||b instanceof class_2421||b instanceof class_3830||b instanceof class_2282;}
 public static class_2758 ageProperty(class_2680 s){for(class_2769<?> p:s.method_28501())if(p instanceof class_2758 a&&"age".equals(p.method_11899()))return a;return null;}
 private static String key(class_3218 w,class_2338 p){return w.method_27983().method_29177()+"|"+p.method_10063();}
 public static void load(MinecraftServer s){
  server=s;file=s.method_27050(class_5218.field_24188).resolve("data/chrono-harvest-planted.json");PLANTED.clear();
  try{if(Files.isRegularFile(file)){Map<String,Long> m=GSON.fromJson(Files.readString(file),TYPE);if(m!=null)PLANTED.putAll(m);}}
  catch(Exception e){System.err.println("[ChronoHarvest] Timestamp load failed: "+e);}lastSave=0;
 }
 public static void save(MinecraftServer s){
  if(file==null)return;
  try{Files.createDirectories(file.getParent());Path tmp=file.resolveSibling(file.getFileName()+".tmp");Files.writeString(tmp,GSON.toJson(PLANTED));
   try{Files.move(tmp,file,java.nio.file.StandardCopyOption.REPLACE_EXISTING,java.nio.file.StandardCopyOption.ATOMIC_MOVE);}
   catch(java.nio.file.AtomicMoveNotSupportedException e){Files.move(tmp,file,java.nio.file.StandardCopyOption.REPLACE_EXISTING);}
  }catch(Exception e){System.err.println("[ChronoHarvest] Timestamp save failed: "+e);}
 }
 public static void periodicSave(){if(server!=null&&server.method_3780()-lastSave>=200){save(server);lastSave=server.method_3780();}}
 public static void markPlanted(class_3218 w,class_2338 p){PLANTED.put(key(w,p),System.currentTimeMillis());}
 public static void forget(class_3218 w,class_2338 p){PLANTED.remove(key(w,p));}
 public static boolean applyElapsedGrowth(class_3218 w,class_2338 p){
  if(!ChronoHarvest.CONFIG.enabled)return false;class_2680 s=w.method_8320(p);if(!supported(s))return false;
  class_2758 age=ageProperty(s);if(age==null)return false;
  long planted=PLANTED.computeIfAbsent(key(w,p),k->System.currentTimeMillis());
  long elapsed=Math.max(0,System.currentTimeMillis()-planted), stageMs=ChronoHarvest.CONFIG.secondsPerStage*1000L;
  int max=age.method_11898().stream().mapToInt(Integer::intValue).max().orElse(0);
  int expected=(int)Math.min(max,elapsed/stageMs), current=s.method_11654(age);
  if(expected>current)w.method_8652(p,s.method_11657(age,expected),3);
  return true;
 }
 public static void onChunkLoad(class_3218 w,class_2818 c){
  if(!ChronoHarvest.CONFIG.enabled)return;int sx=c.method_12004().method_8326(),sz=c.method_12004().method_8328();
  int topY=w.method_31607()+w.method_31605();
  for(int x=0;x<16;x++)for(int z=0;z<16;z++)for(int y=w.method_31607();y<topY;y++){
   class_2338 p=new class_2338(sx+x,y,sz+z);if(supported(c.method_8320(p)))applyElapsedGrowth(w,p);
  }
 }
}
